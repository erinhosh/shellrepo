#!/bin/bash

readonly name="idrees"
abc=$(hostid)
xyz=$(pwd)
echo "My name is $name and hostname of my system is $abc and working directory is $xyz"
name="praful"

