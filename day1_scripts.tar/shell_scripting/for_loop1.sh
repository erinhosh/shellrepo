#!/bin/bash

for i in 11 14 17 18 112 20
do 
	echo " number is $i"
done

for cityName in Indore Pune Jaipur Noida Amritsar Shimla
do 
	echo "My fav city is $cityName"
done

for x in {5..13}
do
	echo "my number is $x"
done

